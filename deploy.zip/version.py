from __future__ import print_function
# we're following the version number guidelines
# from https://www.python.org/dev/peps/pep-0386/

__version__ = "0.3.0"

if __name__ == "__main__":
    print(__version__)
